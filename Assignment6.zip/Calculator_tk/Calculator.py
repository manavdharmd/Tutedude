"""
Calculator using Tk
"""
import tkinter as tk
from tkinter import *

def click(e,num):
    print(num," clicked")
    result = e.get()
    e.delete(0,END)
    e.insert(0,str(result)+str(num))


def Cal_Input(window):
    print("Input box created")
    e = Entry(window,width=30,borderwidth=10)
    e.place(x=20,y=10)
    return e


def Cal_Button_auto(window,e):
    print("Buttons")
    # No 1-9
    for i in range(1,10):
        if i<=3:
            l=1
        elif i>3 and i<=6:
            l=1.5
        elif i>6 and i<=9:
            l=2
        b = Button(window,text=i,width=10,borderwidth=2,command=lambda:click(e,i))
        b.place(x=10+68*((i-1)%3),y=68*l)
    # No 0,-,+,/,=
    Cal_list = ['0','+','-','*','/','=']
    k=1
    for i in Cal_list:
        b=Button(window,text=i,width=10,borderwidth=2,command=lambda:click(e,i))
        b.place(x=10 + 68 * (k - 1), y=68 * 2.5)
        b = Button(window, text=i, width=10, borderwidth=2,command=lambda:click(e,i))
        b.place(x=10 + 68 * (k - 1), y=68 * 3)
        if k==3:
            k=0
        k += 1
    b = Button(window, text='Clear', width=30, borderwidth=2)
    b.place(x=10 + 68 * (1 - 1), y=68 * 3.5)

def Cal_Button(window,e):
    print("Cal_Button")
    b = Button(window, text=1, width=10, borderwidth=2, command=lambda: click(e, 1))
    b.place(x=10, y=68)
    b = Button(window, text=2, width=10, borderwidth=2, command=lambda: click(e, 2))
    b.place(x=10+68, y=68)
    b = Button(window, text=3, width=10, borderwidth=2, command=lambda: click(e, 3))
    b.place(x=10+68*2, y=68)

    b = Button(window, text=4, width=10, borderwidth=2, command=lambda: click(e, 4))
    b.place(x=10, y=68*1.5)
    b = Button(window, text=5, width=10, borderwidth=2, command=lambda: click(e, 5))
    b.place(x=10 + 68, y=68*1.5)
    b = Button(window, text=6, width=10, borderwidth=2, command=lambda: click(e, 6))
    b.place(x=10 + 68 * 2, y=68*1.5)

    b = Button(window, text=7, width=10, borderwidth=2, command=lambda: click(e, 7))
    b.place(x=10, y=68*2)
    b = Button(window, text=8, width=10, borderwidth=2, command=lambda: click(e, 8))
    b.place(x=10 + 68, y=68*2)
    b = Button(window, text=9, width=10, borderwidth=2, command=lambda: click(e, 9))
    b.place(x=10 + 68 * 2, y=68*2)

    b = Button(window, text=0, width=10, borderwidth=2, command=lambda: click(e, 0))
    b.place(x=10, y=68*2.5)
    b = Button(window, text='+', width=10, borderwidth=2, command=lambda: add(e))
    b.place(x=10 + 68, y=68*2.5)
    b = Button(window, text='-', width=10, borderwidth=2, command=lambda: sub(e))
    b.place(x=10 + 68 * 2, y=68*2.5)

    b = Button(window, text='*', width=10, borderwidth=2, command=lambda: mul(e))
    b.place(x=10, y=68 * 3)
    b = Button(window, text='/', width=10, borderwidth=2, command=lambda: div(e))
    b.place(x=10 + 68, y=68 * 3)
    b = Button(window, text='=', width=10, borderwidth=2, command=lambda: Eq(e))
    b.place(x=10 + 68 * 2, y=68 * 3)

    b = Button(window, text='CLEAR', width=30, borderwidth=2, command=lambda: clear(e))
    b.place(x=10, y=68 * 3.5)


def add(e):
    print("Add")
    global i
    global math
    n1 = e.get()
    e.delete(0, END)
    try:
        i = int(n1)
    except Exception:
        e.insert(0, "Error : Please clear and start over")
    math = "Add"


def sub(e):
    print("Sub")
    global i
    global math
    n1 = e.get()
    e.delete(0, END)
    try:
        i = int(n1)
    except Exception:
        e.insert(0, "Error : Please clear and start over")
    math="Sub"

def mul(e):
    print("Mul")
    global i
    global math
    n1 = e.get()
    e.delete(0, END)
    try:
        i = int(n1)
    except Exception:
        e.insert(0, "Error : Please clear and start over")
    math="Mul"

def div(e):
    print("Div")
    global i
    global math
    n1 = e.get()
    e.delete(0, END)
    try:
        i = int(n1)
    except Exception:
        e.insert(0, "Error : Please clear and start over")
    math = "Div"

def clear(e):
    print("Clear")
    i=0
    n2=0
    e.delete(0, END)

def Eq(e):
    print("Eq")
    global n2
    try:
        n2 = int(e.get())
        e.delete(0, END)
        total = 0
        if math == "Add":
            print("Add")
            total=i+n2
        if math == "Sub":
            print("Sub")
            total =i-n2
        if math == "Div":
            print("Div")
            total = i/n2
        if math == "Mul":
            print("Mul")
            total = i*n2
        e.insert(0, total)
        n1=0
        n2=0
    except ZeroDivisionError :
        print("Div by zero")
        e.insert(0,"Error : Please clear and start over: Div/0")
    except Exception:
        print("Err")
        e.insert(0,"Error : Please clear and start over")


def Cal_Gui():
    print("GUI_Open")
    window=Tk()
    window.title("Calculator")
    window.geometry("250x300")


    # Entry Prompt
    Input_e=Cal_Input(window)
    Cal_Button(window,Input_e)

    window.mainloop()
    print("GUI_Close")


Cal_Gui()
