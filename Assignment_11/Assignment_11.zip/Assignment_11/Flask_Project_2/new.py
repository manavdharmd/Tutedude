#Importing
from flask import Flask,render_template,request
import os
# Interaction
app = Flask(__name__)

picfolder = os.path.join('static')
app.config['UPLOAD_FOLDER'] = picfolder
# Mapping
@app.route('/')

# Inputs
def first():
    pic = os.path.join(app.config['UPLOAD_FOLDER'],'waterfall.png')
    return render_template("home.html",user_image=pic)

# Mapping
@app.route('/second')

# Inputs
def second():
    return render_template("second.html")

# Main
if __name__ == "__main__":
    app.run(debug=True)